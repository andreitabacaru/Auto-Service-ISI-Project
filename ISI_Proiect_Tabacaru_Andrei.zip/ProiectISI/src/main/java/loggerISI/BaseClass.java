package loggerISI;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.Logger;

public class BaseClass {
	
	
	public static Logger logger = LogManager.getLogger(BaseClass.class);
	

	
	public static void main(String[] args) {
		
		
		System.out.println("\n Hello \n");
		
		logger.info("S-a dat run la fisierul BaseClass.java");
		logger.error("This is an error message");
		logger.warn("This is an warning message");
		logger.fatal("This is an fatal message");
		
		System.out.println("\n Hello \n");
		

	}

}
