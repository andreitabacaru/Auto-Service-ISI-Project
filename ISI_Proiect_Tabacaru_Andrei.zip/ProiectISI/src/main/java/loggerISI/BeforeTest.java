package loggerISI;

public @interface BeforeTest {

}
