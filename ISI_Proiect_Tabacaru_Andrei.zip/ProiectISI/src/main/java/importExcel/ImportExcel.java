package importExcel;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.apache.poi.xssf.usermodel.*;



public class ImportExcel {

	public List<ImportBean> importFromExcel() throws IOException {
		
		
		String excelFilePath="C:\\Users\\Andrei Tabacaru\\Desktop\\FACULTATE\\Anul 4\\ISI\\ProiectISI\\Autoturisme_01_2022.xlsx";
		FileInputStream inputstream=new FileInputStream(excelFilePath);
        
		XSSFWorkbook workbook=new XSSFWorkbook(inputstream);
		XSSFSheet sheet=workbook.getSheetAt(0);
			
		///////// Iterator ////////////////////////
		
		Iterator iterator=sheet.iterator();
		
		List<ImportBean> users = new ArrayList<>();
		
		int count = 0;
		
		DecimalFormat format = new DecimalFormat("0.#");
		
		while(iterator.hasNext())
		{
			XSSFRow row=(XSSFRow) iterator.next();
			
			if(count>0) {
			
			Iterator cellIterator=row.cellIterator();
			
			while(cellIterator.hasNext())
			{
				
				double id_auto = 0.0;
            	String marca = "";
            	String culoare = "";
        		String model = "";
        		String caroserie = "";
        		double an_fabricatie = 0.0;
        		String cap_cilindrica= "";;
        		String carburant= "";
				String id_auto_2 = "";
				String an_fabricatie_2 = "";
				
				for(int i=0;i<=7;i++) {
					XSSFCell cell=(XSSFCell) cellIterator.next();
					
					if(i==0) {
						id_auto = cell.getNumericCellValue();
						id_auto_2 = format.format(id_auto);
					}
					if(i==1) {
						marca = cell.getStringCellValue();
					}
					if(i==2) {
						culoare = cell.getStringCellValue();
					}
					if(i==3) {
						model = cell.getStringCellValue();
					}
					if(i==4) {
						caroserie = cell.getStringCellValue();
					}
					if(i==5) {
						an_fabricatie = cell.getNumericCellValue();
						an_fabricatie_2 = format.format(an_fabricatie);
					}
					if(i==6) {
						cap_cilindrica= cell.getStringCellValue();
					}
					if(i==7) {
						carburant= cell.getStringCellValue();
					}
				}
				
				users.add(new ImportBean(id_auto_2,marca,culoare,model,caroserie,an_fabricatie_2,cap_cilindrica,carburant));
	
				}
			}
			
			count++;
		}
		
		return users;
				
	}
	
}
