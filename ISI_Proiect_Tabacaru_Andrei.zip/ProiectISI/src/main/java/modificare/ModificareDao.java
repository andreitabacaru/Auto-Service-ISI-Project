package modificare;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import loggerFile.Logger;
import logininfo.LoginBean;

public class ModificareDao {
	
	public boolean validate(ModificareBean update) throws ClassNotFoundException {
        boolean status = false;
        
        Logger logger = new Logger();

        Class.forName("com.mysql.jdbc.Driver");

        try (Connection connection = DriverManager
            .getConnection("jdbc:mysql://127.0.0.1:3306/gestiune_service_auto", "root", "");
        		
        
        	//TODO: De gandit cum obtii cheia id_auto ???	
            
        	PreparedStatement preparedStatement = connection
        	.prepareStatement("UPDATE autoturisme SET marca = ?, culoare = ?, model = ?, caroserie = ?, an_fabricatie = ?, cap_cilindrica = ?, carburant = ? WHERE id_auto = ?")) {
            preparedStatement.setString(1, update.getMarca());
            preparedStatement.setString(2, update.getCuloare());
            preparedStatement.setString(3, update.getModel());
            preparedStatement.setString(4, update.getCaroserie());
            preparedStatement.setString(5, update.getAn_fabricatie());
            preparedStatement.setString(6, update.getCap_cilindrica());
            preparedStatement.setString(7, update.getCarburant());
            preparedStatement.setInt(8,update.getId_auto());
            
            
            //Print the SQL Statement
            System.out.println(preparedStatement);
            status = preparedStatement.executeUpdate() > 0;
            
            logger.logger(preparedStatement.toString(), "manager");

        } catch (SQLException e) {
            // process sql exception
            printSQLException(e);
        }
        return status; 
    }
	
	private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
	
}
