package modificare;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class ModificareServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ModificareServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int id_auto = Integer.parseInt(request.getParameter("id_auto"));
		
		String marca = request.getParameter("marca");
		String culoare = request.getParameter("culoare");
		String model = request.getParameter("model");
		String caroserie = request.getParameter("caroserie");
		String an_fabricatie= request.getParameter("an_fabricatie");
		String cap_cilindrica= request.getParameter("cap_cilindrica");
		String carburant= request.getParameter("carburant");
	
		
		
		ModificareBean member = new ModificareBean(id_auto, marca, culoare, model, caroserie, an_fabricatie, cap_cilindrica, carburant);

		
		ModificareDao update = new ModificareDao();
		Boolean result = null;
		try {
			result = update.validate(member);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		if (result.equals(true)) {
		    HttpSession session = request.getSession();
		    session.setAttribute("id_auto",id_auto);
		    RequestDispatcher dispatcher = request.getRequestDispatcher("VizualizareTabel.jsp");
		    dispatcher.forward(request, response);
		   // response.sendRedirect("VizualizareTabel.jsp");
		} else {
			response.getWriter().print(result);
			response.getWriter().print("\nA esuat");
		}
	}
	
}
