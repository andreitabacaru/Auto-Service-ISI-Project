package export;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Year;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;


import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.util.List;
import java.util.Locale;

import select.SelectBean;

public class ExportDao {
	
	private XSSFWorkbook workbook;
	private XSSFSheet sheet;
	
	
	public void setReponseHeader(HttpServletResponse response, String contentType, String extension, String prefix) throws IOException, ParseException{
		
		DateFormat outputFormat = new SimpleDateFormat("MM/yyyy", Locale.US);
		DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX", Locale.US);
		
		String inputText = "2022-01-12T00:00:00.000-05:00";
		Date date = inputFormat.parse(inputText);
		String outputText = outputFormat.format(date);
		
//		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
//		String timeStamp = dateFormat.format(new Date());
		String fileName = prefix + outputText + extension;
		
		response.setContentType(contentType);
		
		String headerKey = "Content-Disposition";
		String headerValue = "attachment; filename=" + fileName;
		response.setHeader(headerKey, headerValue);
	}
	
	public void exportToEXCEL(List<SelectBean> listAutoturisme, HttpServletResponse response) throws IOException, ParseException{
		
		workbook = new XSSFWorkbook();
		setReponseHeader(response, "application/octet-stream", ".xlsx", "Autoturisme_");
		
		writeHeaderLine();
		writeDataLine(listAutoturisme);
		
		ServletOutputStream outStream = response.getOutputStream();
		workbook.write(outStream);
		workbook.close();
		outStream.close();
		
	}
	
	private void writeHeaderLine() {
		
		sheet = workbook.createSheet("Autoturisme");
		XSSFRow row = sheet.createRow(0);
		XSSFCellStyle cellStyle = workbook.createCellStyle();
		XSSFFont font = workbook.createFont();
		font.setBold(true);
		font.setFontHeight(16);
		cellStyle.setFont(font);
		
		createCell(row, 0, "ID", cellStyle);
		createCell(row, 1, "Marca", cellStyle);
		createCell(row, 2, "Culoare", cellStyle);
		createCell(row, 3, "Model", cellStyle);
		createCell(row, 4, "Caroserie", cellStyle);
		createCell(row, 5, "An fabricatie", cellStyle);
		createCell(row, 6, "Capacitate cilindrica", cellStyle);
		createCell(row, 7, "Carburant", cellStyle);

	}
	
	private void createCell(XSSFRow row, int columnIndex, Object value, CellStyle style) {
		
		XSSFCell cell = row.createCell(columnIndex);
		sheet.autoSizeColumn(columnIndex);
		if(value instanceof Integer)
			cell.setCellValue((Integer)value);
		else if(value instanceof Boolean)
			cell.setCellValue((Boolean)value);
		else if(value instanceof Year)
			cell.setCellValue((Integer)value);
		else
			cell.setCellValue((String)value);
		
		cell.setCellStyle(style);
		
	}
	
	private void writeDataLine(List<SelectBean> listAutoturisme) {
		int rowIndex = 1;
		
		XSSFCellStyle cellStyle = workbook.createCellStyle();
		XSSFFont font = workbook.createFont();
		font.setFontHeight(14);
		cellStyle.setFont(font);
		
		
		for(SelectBean select : listAutoturisme) {
			
			XSSFRow row = sheet.createRow(rowIndex++);
			int columnIndex = 0;
			createCell(row, columnIndex++, select.getId_auto(), cellStyle);
			createCell(row, columnIndex++, select.getMarca(), cellStyle);
			createCell(row, columnIndex++, select.getCuloare(), cellStyle);
			createCell(row, columnIndex++, select.getModel(), cellStyle);
			createCell(row, columnIndex++, select.getCaroserie(), cellStyle);
			createCell(row, columnIndex++, select.getAn_fabricatie(), cellStyle);
			createCell(row, columnIndex++, select.getCap_cilindrica(), cellStyle);
			createCell(row, columnIndex++, select.getCarburant(), cellStyle);
		}
	}
	

}
