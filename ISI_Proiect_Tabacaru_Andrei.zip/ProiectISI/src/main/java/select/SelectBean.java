package select;

import java.sql.Date;


public class SelectBean {
	
	private int id_auto;
	private String marca, culoare, model, caroserie, cap_cilindrica, carburant;
	private int an_fabricatie;
	
	
	public SelectBean() {
		super();
	}
	
	
	public SelectBean(int id_auto, String marca, String culoare, String model, String caroserie,
			int an_fabricatie, String cap_cilindrica, String carburant) {
		super();
		this.id_auto = id_auto;
		this.marca = marca;
		this.culoare = culoare;
		this.model = model;
		this.caroserie = caroserie;
		this.an_fabricatie = an_fabricatie;
		this.cap_cilindrica = cap_cilindrica;
		this.carburant = carburant;
	}
	
	
	public int getId_auto() {
		return id_auto;
	}
	public void setId_auto(int id_auto) {
		this.id_auto = id_auto;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getCuloare() {
		return culoare;
	}
	public void setCuloare(String culoare) {
		this.culoare = culoare;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getCaroserie() {
		return caroserie;
	}
	public void setCaroserie(String caroserie) {
		this.caroserie = caroserie;
	}
	public int getAn_fabricatie() {
		return an_fabricatie;
	}
	public void setAn_fabricatie(int an_fabricatie) {
		this.an_fabricatie = an_fabricatie;
	}
	public String getCap_cilindrica() {
		return cap_cilindrica;
	}
	public void setCap_cilindrica(String cap_cilindrica) {
		this.cap_cilindrica = cap_cilindrica;
	}
	public String getCarburant() {
		return carburant;
	}
	public void setCarburant(String carburant) {
		this.carburant = carburant;
	}
	
	
}
