package loggerFile;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public  class Logger {
    
    private static String jdbcURL = "jdbc:mysql://127.0.0.1:3306/gestiune_service_auto";
	private static String jdbcUsername = "root";
	private static String jdbcPassword = "";
        
        private static String INSERT_LOG = "INSERT INTO `log` (`operatie`,`comanda`, `user`, `dataora`) VALUES (?,?,?,SYSDATE())";
    
    protected static Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}
    
    
	
    public static void logger(String comanda, String user) {
        try { Connection connection = getConnection();

            PreparedStatement pst = connection.prepareStatement(INSERT_LOG);
             String comanda1;

            {
            comanda1 = comanda.substring(comanda.indexOf(" ") + 1);
            comanda1.trim();
            System.out.println(comanda1.split(" ")[0]);
            }

            String operatie;
            
            switch (comanda1.split(" ")[0].toUpperCase()) {
                case "INSERT":
                    operatie = "Inserare";
                    break;

                case "SELECT":
                    operatie = "Citire";
                    break;
                case "UPDATE":
                    operatie = "Actualizare";
                    break;
                case "DELETE":

                    operatie = "Stergere";
                    break;

                default:
                    operatie = "Alta operatie";

            }
            
            pst.setString(1, operatie);
            pst.setString(2, comanda1);
            pst.setString(3, user);
            pst.executeUpdate();

        } catch (SQLException e) {
            printSQLException(e);

        }
    }
    
private static void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}
    
    
}