package insert;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import loggerFile.Logger;

public class InsertDao {
	
	private String dbUrl = "jdbc:mysql://127.0.0.1:3306/gestiune_service_auto";
	private String dbUname = "root";
	private String dbPassword = "";
	private String dbDriver = "com.mysql.cj.jdbc.Driver";
	
	public void loadDriver(String dbriver)
	{
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Connection getConnection()
	{
		Connection con = null;
		try {
			con = DriverManager.getConnection(dbUrl, dbUname, dbPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return con;
	}
	
	public String insert(InsertBean insert) 
	{
		Logger logger = new Logger();
		
		loadDriver(dbDriver);
		Connection con = getConnection();
		String result = "True";
		
		String sql = "insert into autoturisme(marca, culoare, model, caroserie, an_fabricatie, cap_cilindrica, carburant) values(?,?,?,?,?,?,?)";
		
		PreparedStatement ps;
		
		try {
			ps = con.prepareStatement(sql);
		
		ps.setString(1, insert.getMarca());
		ps.setString(2, insert.getCuloare());
		ps.setString(3, insert.getModel());
		ps.setString(4, insert.getCaroserie());
		ps.setString(5, insert.getAn_fabricatie());
		ps.setString(6, insert.getCap_cilindrica());
		ps.setString(7, insert.getCarburant());
		
		
		ps.execute();
		
        logger.logger(ps.toString(), "manager");
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = "Data failed to be inserted!!!";
		}
		
		return result;
		
	}
}
