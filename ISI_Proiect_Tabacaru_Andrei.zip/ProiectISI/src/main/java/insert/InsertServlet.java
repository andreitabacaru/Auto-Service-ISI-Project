package insert;




import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * Servlet implementation class InsertServlet
 */
public class InsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String marca = request.getParameter("marca");
		String culoare = request.getParameter("culoare");
		String model = request.getParameter("model");
		String caroserie = request.getParameter("caroserie");
		String an_fabricatie= request.getParameter("an_fabricatie");
		String cap_cilindrica= request.getParameter("cap_cilindrica");
		String carburant= request.getParameter("carburant");
	
		
		
		InsertBean member = new InsertBean(marca, culoare, model, caroserie, an_fabricatie, cap_cilindrica, carburant);

		
		InsertDao rDao = new InsertDao();
		String result = rDao.insert(member);
		
		//response.getWriter().print(result);
		
		if (result == "True") {
		    HttpSession session = request.getSession();
		    session.setAttribute("marca",marca);
		    response.sendRedirect("InsertAutoturisme.jsp");
		} else {
			response.getWriter().print(result);
		}
	}
}

