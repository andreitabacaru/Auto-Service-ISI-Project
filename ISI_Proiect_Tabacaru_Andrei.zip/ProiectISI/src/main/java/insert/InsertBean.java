package insert;

public class InsertBean {
	
	private String marca, culoare, model, caroserie, carburant;
	private String an_fabricatie;
	private String cap_cilindrica;
	
	
	public InsertBean() {
		super();
	}
	
	public InsertBean(String marca, String culoare, String model, String caroserie, String an_fabricatie,
			String cap_cilindrica, String carburant) {
		super();
		this.marca = marca;
		this.culoare = culoare;
		this.model = model;
		this.caroserie = caroserie;
		this.an_fabricatie = an_fabricatie;
		this.cap_cilindrica = cap_cilindrica;
		this.carburant = carburant;
		
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getCuloare() {
		return culoare;
	}
	public void setCuloare(String culoare) {
		this.culoare = culoare;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getCaroserie() {
		return caroserie;
	}
	public void setCaroserie(String caroserie) {
		this.caroserie = caroserie;
	}
	
	public String getAn_fabricatie() {
		return an_fabricatie;
	}
	public void setAn_fabricatie(String an_fabricatie) {
		this.an_fabricatie = an_fabricatie;
	}
	public String getCap_cilindrica() {
		return cap_cilindrica;
	}
	public void setCap_cilindrica(String cap_cilindrica) {
		this.cap_cilindrica = cap_cilindrica;
	}
	public String getCarburant() {
		return carburant;
	}
	public void setCarburant(String carburant) {
		this.carburant = carburant;
	}

}
