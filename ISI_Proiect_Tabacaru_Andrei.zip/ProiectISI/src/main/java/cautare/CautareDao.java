package cautare;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import loggerFile.Logger;
import logininfo.LoginBean;


public class CautareDao {
	
public CautareBean search(int id_auto) throws ClassNotFoundException {
        
        CautareBean user = null;
        
        Logger logger = new Logger();
        
        Class.forName("com.mysql.jdbc.Driver");

        try (Connection connection = DriverManager
            .getConnection("jdbc:mysql://127.0.0.1:3306/gestiune_service_auto", "root", "");

            
        	PreparedStatement preparedStatement = connection
        	.prepareStatement("select id_auto, marca, culoare, model, caroserie, an_fabricatie, cap_cilindrica, carburant from autoturisme where id_auto = ?")) {
            preparedStatement.setInt(1, id_auto);
           
            
            //Print the SQL Statement
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();
            
            
            while(rs.next()) {
            	String marca = rs.getString("marca");
            	String culoare = rs.getString("culoare");
        		String model = rs.getString("model");
        		String caroserie = rs.getString("caroserie");
        		int an_fabricatie= rs.getInt("an_fabricatie");
        		String cap_cilindrica= rs.getString("cap_cilindrica");
        		String carburant= rs.getString("carburant");
        		
        		user = new CautareBean(id_auto, marca, culoare, model, caroserie, an_fabricatie, cap_cilindrica, carburant);
            }
            
            logger.logger(preparedStatement.toString(), "manager");
            
        } catch (SQLException e) {
            // process sql exception
            printSQLException(e);
        }
        return user; 
    }

	private void printSQLException(SQLException ex) {
	    for (Throwable e: ex) {
	        if (e instanceof SQLException) {
	            e.printStackTrace(System.err);
	            System.err.println("SQLState: " + ((SQLException) e).getSQLState());
	            System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
	            System.err.println("Message: " + e.getMessage());
	            Throwable t = ex.getCause();
	            while (t != null) {
	                System.out.println("Cause: " + t);
	                t = t.getCause();
	            }
	        }
	    }
	}

}
