package delete;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class DeleteServlet extends HttpServlet{
	
private static final long serialVersionUID = 1L;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		int id_auto = Integer.parseInt(request.getParameter("id_auto"));

		
		DeleteDao delete = new DeleteDao();
		Boolean result = null;
		try {
			result = delete.deleteAutoturisme(id_auto);
			
			if (result.equals(true)) {
				HttpSession session = request.getSession();
			    session.setAttribute("id_auto",id_auto);
			    RequestDispatcher dispatcher = request.getRequestDispatcher("VizualizareTabel.jsp");
			    dispatcher.forward(request, response);
			} else {
				response.getWriter().print(result);
				
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//response.getWriter().print(result);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
//		int id_auto = Integer.parseInt(request.getParameter("id_auto"));
//
//		
//		DeleteDao delete = new DeleteDao();
//		Boolean result = null;
//		try {
//			result = delete.deleteAutoturisme(id_auto);
//		} catch (ClassNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		//response.getWriter().print(result);
//		
//		if (result.equals(true)) {
//		    HttpSession session = request.getSession();
//		    response.sendRedirect("VizualizareTabel.jsp");
//		} else {
//			response.getWriter().print(result);
//		}
	}
}
